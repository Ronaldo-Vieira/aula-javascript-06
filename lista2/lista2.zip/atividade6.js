let text = "Posso comer bananas o dia todo"
console.log(text.length)