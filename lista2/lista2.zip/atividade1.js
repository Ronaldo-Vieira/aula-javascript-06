let text = "abcdefghijklm"
console.log(text.indexOf("h"))