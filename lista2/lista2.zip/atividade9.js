let frutas = ["Banana", "Orange", "Apple", "Kiwi"]
frutas.shift()
frutas.pop()
console.log(frutas)