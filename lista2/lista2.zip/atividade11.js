let frutas = ["Banana", "Orange", "Apple"]
frutas.unshift("Pera","Manga")
frutas.pop()
console.log(frutas)