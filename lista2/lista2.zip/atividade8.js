let fruits = ["Banana", "Orange", "Apple", "Kiwi"]
fruits.sort()
console.log(fruits)