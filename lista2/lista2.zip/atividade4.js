let text = "Olá, mundo"
console.log(text.toLocaleUpperCase())