let text = "Posso comer bananas o dia todo"
console.log(text.slice(12,19))