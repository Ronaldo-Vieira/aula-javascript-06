let text1 = "Hello "
let text2 = "World!"
console.log(text1 + text2)