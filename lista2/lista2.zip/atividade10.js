let frutas = ["Banana", "Orange", "Apple"]
frutas.push("Uva","Caju", "Kiwi")
console.log(frutas)